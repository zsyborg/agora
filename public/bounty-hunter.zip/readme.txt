﻿=== Bounty Hunter Cursor Set ===

By: Acrux (http://www.rw-designer.com/user/53102) anynamethen@gmail.com

Download: http://www.rw-designer.com/cursor-set/bounty-hunter

Author's description:

Well not a whole lot in the description of this one ,as he is a bounty hunter ,and that means officially  he is off the grid.

hope you all like it 
please let me know !

PS: ,I added an extra cursor in case anyone prefers it to the original working or busy cursors

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.